import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData, rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../providers/auth_provider.dart';
import '../../../../providers/booking_provider.dart';
import '../../../../providers/payment_provider.dart';
import '../../../../providers/wallet_provider.dart';
import '../../../../data/models/booking_history_item.dart';
import '../../../../data/services/promo_code_service.dart';
import '../../../../core/exceptions/api_exception.dart';
import '../../../theme/app_tokens.dart';
import '../../../widgets/field_widget.dart';
import '../../auth/change_password_screen.dart';
import '../../admin/admin_active_trips_screen.dart';
import 'current_bookings_page.dart';
import 'booking_history_page.dart';
import 'payment_history_page.dart';
import 'wallet_page.dart';

class MyAccountPage extends StatefulWidget {
  const MyAccountPage({super.key});

  @override
  State<MyAccountPage> createState() => _MyAccountPageState();
}

class _MyAccountPageState extends State<MyAccountPage> {
  @override
  void initState() {
    super.initState();
    // Load bookings and payment info
    Future.microtask(() {
      context.read<BookingProvider>().refreshBookings();
      context.read<PaymentProvider>().loadCards();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final authProvider = context.watch<AuthProvider>();
    final isAdmin = authProvider.currentUser?.role == 'admin';
    final bookingProvider = context.watch<BookingProvider>();
    final paymentProvider = context.watch<PaymentProvider>();

    // Calculate counts
    final currentBookingsCount = bookingProvider.bookings
        .where((b) => b.bookingStatus != 'COMPLETED')
        .length;
    final historyBookingsCount = bookingProvider.bookings
        .where((b) => b.bookingStatus == 'COMPLETED')
        .length;

    // Calculate ride statistics
    final totalRides = bookingProvider.bookings.length;
    final pointToPointRides = bookingProvider.bookings
        .where((b) => b.type == BookingType.pointToPoint)
        .length;
    final hourlyRides = bookingProvider.bookings
        .where((b) => b.type == BookingType.hourlyCharter)
        .length;
    final airportRides = bookingProvider.bookings
        .where((b) => b.type == BookingType.airport)
        .length;

    return ListView(
      padding: const EdgeInsets.all(AppSpacing.md),
      children: [
        // Enhanced header with profile and actions
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'My Account',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            FilledButton.icon(
              onPressed: () async {
                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Logout'),
                    content: const Text('Are you sure you want to logout?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: const Text('Cancel'),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.of(context).pop(true),
                        child: const Text('Logout'),
                      ),
                    ],
                  ),
                );
                if (confirmed == true) {
                  context.read<BookingProvider>().resetRealtimeState();
                  await context.read<AuthProvider>().logout();
                }
              },
              icon: const Icon(Icons.logout, size: 18),
              label: const Text('Logout'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.md,
                  vertical: 12,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // User Profile Header with profile image at the top
        _UserProfileHeader(paymentProvider: paymentProvider),
        const SizedBox(height: AppSpacing.lg),

        // Ride Statistics Section
        _RideStatisticsCard(
          totalRides: totalRides,
          pointToPointRides: pointToPointRides,
          hourlyRides: hourlyRides,
          airportRides: airportRides,
        ),
        const SizedBox(height: AppSpacing.lg),

        // Wallet Credit Balance (accumulated referral rewards, auto-applies
        // toward future bookings)
        const _WalletBalanceCard(),
        const SizedBox(height: AppSpacing.lg),

        // Savings & Rewards Summary
        const _DiscountSummaryCard(),
        const SizedBox(height: AppSpacing.lg),

        // Active Promotion (a currently-live public promo code, if any)
        const _ActivePromoCard(),
        const SizedBox(height: AppSpacing.lg),

        // Referral Code Section
        const _ReferralCodeCard(),
        const SizedBox(height: AppSpacing.lg),

        // My Bookings Section
        _SectionCard(
          title: 'My Bookings',
          icon: Icons.receipt_long_rounded,
          iconColor: colorScheme.primary,
          children: [
            _MenuItem(
              title: 'Current Bookings',
              icon: Icons.event_available_rounded,
              badge: currentBookingsCount > 0 ? currentBookingsCount : null,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CurrentBookingsPage(),
                  ),
                );
              },
            ),
            const Divider(height: 1),
            _MenuItem(
              title: 'Booking History',
              icon: Icons.history_rounded,
              badge: historyBookingsCount > 0 ? historyBookingsCount : null,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const BookingHistoryPage(),
                  ),
                );
              },
            ),
          ],
        ),

        const SizedBox(height: AppSpacing.md),

        // Payments Section
        _SectionCard(
          title: 'Payments',
          icon: Icons.payment_rounded,
          iconColor: colorScheme.tertiary,
          children: [
            _MenuItem(
              title: 'Payment Methods',
              icon: Icons.credit_card_rounded,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const WalletPage(),
                  ),
                );
              },
            ),
            const Divider(height: 1),
            _MenuItem(
              title: 'Payment History',
              icon: Icons.history_rounded,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const PaymentHistoryPage(),
                  ),
                );
              },
            ),
          ],
        ),

        const SizedBox(height: AppSpacing.md),

        // Account Management Section
        _SectionCard(
          title: 'Account',
          icon: Icons.person_rounded,
          iconColor: Colors.red,
          children: [
            _MenuItem(
              title: 'Change Password',
              icon: Icons.lock_rounded,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ChangePasswordScreen(),
                  ),
                );
              },
            ),
            const Divider(height: 1),
            _MenuItem(
              title: 'Delete Account',
              icon: Icons.delete_forever_rounded,
              iconColor: Colors.red,
              onTap: () => _showDeleteAccountDialog(context),
            ),
          ],
        ),

        if (isAdmin) ...[
          const SizedBox(height: AppSpacing.md),
          _SectionCard(
            title: 'Admin Panel',
            icon: Icons.admin_panel_settings,
            iconColor: const Color(0xFFF472B6),
            children: [
              _MenuItem(
                title: 'Active Trips Control',
                icon: Icons.speed,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AdminActiveTripsScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ],
    );
  }

  Future<void> _showDeleteAccountDialog(BuildContext context) async {
    final authProvider = context.read<AuthProvider>();

    // First confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Delete Account',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Are you sure you want to permanently delete your account?',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 12),
            Text(
              'This action cannot be undone. All your data will be permanently deleted, including:',
            ),
            SizedBox(height: AppSpacing.sm),
            Text('• Your profile information'),
            Text('• Booking history'),
            Text('• Payment methods'),
            Text('• All account data'),
            SizedBox(height: 12),
            Text(
              'If you have any active bookings, please cancel them before deleting your account.',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.orange,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Continue'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    // Second confirmation dialog (App Store requirement - prevent accidental deletion)
    final finalConfirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Final Confirmation',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'This is your last chance to cancel.',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 12),
            Text(
              'Your account will be permanently deleted and cannot be recovered. Are you absolutely sure?',
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Delete Forever'),
          ),
        ],
      ),
    );

    if (finalConfirmed != true) return;

    // Show loading indicator
    if (!context.mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    // Delete account
    final success = await authProvider.deleteAccount();

    if (!context.mounted) return;
    Navigator.of(context).pop(); // Close loading dialog

    if (success) {
      // Show success message and navigate to auth screen
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Your account has been permanently deleted.'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 3),
        ),
      );
      // Navigation will happen automatically via AuthProvider state change
    } else {
      // Show error message
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            authProvider.errorMessage ??
                'Failed to delete account. Please try again.',
          ),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }
}

class _UserProfileHeader extends StatelessWidget {
  final PaymentProvider paymentProvider;

  const _UserProfileHeader({required this.paymentProvider});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final user = authProvider.currentUser;
    final theme = Theme.of(context);

    // Get primary payment card
    final primaryCard = paymentProvider.primaryCard;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile image at the top
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                    child: CircleAvatar(
                      radius: 45,
                      backgroundColor: theme.colorScheme.primary,
                      child: Text(
                        user?.fullName.substring(0, 1).toUpperCase() ?? 'O',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: theme.colorScheme.surface,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.verified,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.md),

            // User name
            Center(
              child: Text(
                user?.fullName ?? 'ODA Guest',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xs),

            // Membership status
            Center(
              child: Text(
                'Member since ${_formatMemberSince(user?.createdAt)}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Personal Information & Settings
            Text(
              'Personal Information',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 12),

            // Full Name
            Field(
              label: 'Full Name',
              value: user?.fullName ?? 'Not provided',
            ),
            const SizedBox(height: AppSpacing.sm),

            // Phone
            Field(
              label: 'Phone',
              value: user?.phoneNumber ?? 'Not provided',
            ),
            const SizedBox(height: AppSpacing.sm),

            // Email
            Field(
              label: 'Email',
              value: user?.email ?? 'Not provided',
            ),
            const SizedBox(height: AppSpacing.sm),

            // Preferred Payment
            if (primaryCard != null)
              Field(
                label: 'Preferred Payment',
                value: '${primaryCard.maskedCardNumber} '
                    '(${primaryCard.expirationDate})',
              ),
          ],
        ),
      ),
    );
  }

  static String _formatMemberSince(DateTime? createdAt) {
    if (createdAt == null) return '—';
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${months[createdAt.month - 1]} ${createdAt.year}';
  }
}

class _RideStatisticsCard extends StatelessWidget {
  final int totalRides;
  final int pointToPointRides;
  final int hourlyRides;
  final int airportRides;

  const _RideStatisticsCard({
    required this.totalRides,
    required this.pointToPointRides,
    required this.hourlyRides,
    required this.airportRides,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ride Statistics',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.primary,
              ),
            ),
            const SizedBox(height: AppSpacing.md),

            // Total Summary
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppRadius.lg),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: colorScheme.primary,
                      borderRadius: BorderRadius.circular(AppRadius.md),
                    ),
                    child: const Icon(
                      Icons.list,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$totalRides',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      Text(
                        'Total Rides',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Ride Breakdown
            Row(
              children: [
                // Point-to-Point
                Expanded(
                  child: _RideStatCard(
                    icon: Icons.route,
                    count: pointToPointRides,
                    label: 'Point-to-Point',
                    color: Colors.blue,
                  ),
                ),
                const SizedBox(width: 12),
                // Hourly
                Expanded(
                  child: _RideStatCard(
                    icon: Icons.access_time,
                    count: hourlyRides,
                    label: 'Hourly',
                    color: Colors.red,
                  ),
                ),
                const SizedBox(width: 12),
                // Airport
                Expanded(
                  child: _RideStatCard(
                    icon: Icons.flight_takeoff,
                    count: airportRides,
                    label: 'Airport',
                    color: Colors.green,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _RideStatCard extends StatelessWidget {
  final IconData icon;
  final int count;
  final String label;
  final Color color;

  const _RideStatCard({
    required this.icon,
    required this.count,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(AppSpacing.sm),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            '$count',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _WalletBalanceCard extends StatefulWidget {
  const _WalletBalanceCard();

  @override
  State<_WalletBalanceCard> createState() => _WalletBalanceCardState();
}

class _WalletBalanceCardState extends State<_WalletBalanceCard>
    with AutomaticKeepAliveClientMixin {
  // Without this, ListView disposes this card's State (and re-fetches from
  // scratch) once it scrolls far enough outside the viewport's cache extent
  // — the exact "reloads every time I scroll" symptom this fixes, same as
  // the three cards below.
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    // Shared with the booking forms via WalletProvider (rather than a
    // private WalletService instance like the other account cards use) so
    // the balance shown here and the one auto-applied at checkout always
    // agree without two independent fetches.
    Future.microtask(() {
      if (!mounted) return;
      context.read<WalletProvider>().loadWallet();
      context.read<WalletProvider>().loadCashOutRequests();
    });
  }

  Future<void> _showCashOutDialog(
    BuildContext context,
    WalletProvider walletProvider,
  ) async {
    final amountController = TextEditingController();
    final noteController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    String? submitError;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            final submitting = context.watch<WalletProvider>().isSubmittingCashOut;
            return AlertDialog(
              title: const Text('Request a Cash-Out'),
              content: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "This sends a request to our team — it doesn't pay out "
                        'automatically. Someone will reach out to arrange '
                        'payment outside the app once it\'s reviewed.',
                        style: Theme.of(dialogContext).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Available balance: \$${walletProvider.balance.toStringAsFixed(2)}',
                        style: Theme.of(dialogContext)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: amountController,
                        enabled: !submitting,
                        keyboardType:
                            const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: 'Amount (\$)',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          final amount = double.tryParse(value ?? '');
                          if (amount == null || amount <= 0) {
                            return 'Enter an amount greater than zero';
                          }
                          if (amount > walletProvider.balance) {
                            return 'You only have \$${walletProvider.balance.toStringAsFixed(2)} available';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: noteController,
                        enabled: !submitting,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'Note (optional)',
                          hintText: 'Anything our team should know',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      if (submitError != null) ...[
                        const SizedBox(height: 12),
                        Text(
                          submitError!,
                          style: TextStyle(
                            color: Theme.of(dialogContext).colorScheme.error,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed:
                      submitting ? null : () => Navigator.of(dialogContext).pop(),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: submitting
                      ? null
                      : () async {
                          if (!(formKey.currentState?.validate() ?? false)) return;
                          final amount = double.parse(amountController.text);
                          final result = await walletProvider.requestCashOut(
                            amountRequested: amount,
                            note: noteController.text,
                          );
                          if (result == null) {
                            setDialogState(() {
                              submitError = walletProvider.errorMessage ??
                                  'Could not submit your request. Please try again.';
                            });
                            return;
                          }
                          if (dialogContext.mounted) {
                            Navigator.of(dialogContext).pop();
                          }
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  'Your request to cash out \$${amount.toStringAsFixed(2)} '
                                  'has been sent — our team will reach out to arrange payment.',
                                ),
                                duration: const Duration(seconds: 5),
                              ),
                            );
                          }
                        },
                  child: submitting
                      ? const SizedBox(
                          height: 18,
                          width: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('Submit Request'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Color _cashOutStatusColor(BuildContext context, String status) {
    switch (status) {
      case 'fulfilled':
        return Colors.green;
      case 'cancelled':
        return Colors.grey;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required by AutomaticKeepAliveClientMixin
    final walletProvider = context.watch<WalletProvider>();

    if (walletProvider.isLoading && !walletProvider.hasLoaded) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: SizedBox(
              height: 24,
              width: 24,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
          ),
        ),
      );
    }

    // Non-critical section — a failed/empty load should never block or
    // blank out the rest of the account page, same philosophy as the other
    // three cards above.
    if (!walletProvider.hasLoaded) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.account_balance_wallet_rounded,
                    color: colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Wallet Credit',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Dollars earned from completed referrals — never expires, and '
              'automatically applies toward your next booking.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '\$${walletProvider.balance.toStringAsFixed(2)}',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      Text(
                        'Available Balance',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '\$${walletProvider.lifetimeEarned.toStringAsFixed(2)}',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      Text(
                        'Lifetime Earned',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton(
                onPressed: walletProvider.balance > 0
                    ? () => _showCashOutDialog(context, walletProvider)
                    : null,
                child: const Text('Request cash-out'),
              ),
            ),
            if (walletProvider.balance <= 0)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  "You'll need a balance before you can request a cash-out.",
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            if (walletProvider.cashOutRequests.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Divider(),
              Text(
                'Your cash-out requests',
                style: theme.textTheme.labelMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 4),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 140),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: walletProvider.cashOutRequests.length,
                  itemBuilder: (context, index) {
                    final request = walletProvider.cashOutRequests[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '\$${request.amountRequested.toStringAsFixed(2)}',
                                style: theme.textTheme.bodyMedium,
                              ),
                              if (request.createdAt != null)
                                Text(
                                  '${request.createdAt!.month}/${request.createdAt!.day}/${request.createdAt!.year}',
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                            ],
                          ),
                          Chip(
                            label: Text(
                              request.status,
                              style: const TextStyle(fontSize: 12),
                            ),
                            backgroundColor: _cashOutStatusColor(
                              context,
                              request.status,
                            ).withOpacity(0.15),
                            labelStyle: TextStyle(
                              color: _cashOutStatusColor(
                                context,
                                request.status,
                              ),
                            ),
                            visualDensity: VisualDensity.compact,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DiscountSummaryCard extends StatefulWidget {
  const _DiscountSummaryCard();

  @override
  State<_DiscountSummaryCard> createState() => _DiscountSummaryCardState();
}

class _DiscountSummaryCardState extends State<_DiscountSummaryCard>
    with AutomaticKeepAliveClientMixin {
  final _promoCodeService = PromoCodeService();

  bool _loading = true;
  DiscountSummary? _summary;

  // Without this, ListView disposes this card's State (and re-fetches from
  // scratch) once it scrolls far enough outside the viewport's cache extent
  // — the exact "reloads every time I scroll" symptom this fixes.
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadSummary();
  }

  Future<void> _loadSummary() async {
    try {
      final summary = await _promoCodeService.getMyDiscountSummary();
      if (!mounted) return;
      setState(() {
        _summary = summary;
        _loading = false;
      });
    } catch (_) {
      // Non-critical section — fail silently rather than blocking the rest
      // of the account page (mirrors the referral card's behavior).
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Widget _progressRow(
    ThemeData theme,
    String label,
    int used,
    int? limit, {
    String verb = 'earned',
  }) {
    final colorScheme = theme.colorScheme;

    // Null limit means this bucket is uncapped (e.g. referral rewards
    // earned, or public codes now that each code caps itself instead of a
    // shared lifetime bucket) — show a count instead of a progress bar with
    // no ceiling.
    if (limit == null) {
      return Padding(
        padding: const EdgeInsets.only(bottom: AppSpacing.sm),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            Text(
              '$used $verb of unlimited',
              style: theme.textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.primary,
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  label,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              Text(
                '$used of $limit used',
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: limit > 0 ? (used / limit).clamp(0.0, 1.0) : 0.0,
              minHeight: 8,
              backgroundColor: colorScheme.primary.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation<Color>(colorScheme.primary),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required by AutomaticKeepAliveClientMixin
    if (_loading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: SizedBox(
              height: 24,
              width: 24,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
          ),
        ),
      );
    }

    final summary = _summary;
    if (summary == null) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.savings_rounded, color: colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'My Savings & Rewards',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              "Every discount you've used, and every reward you've earned "
              'by referring friends.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '\$${summary.totalSaved.toStringAsFixed(2)}',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      Text(
                        'Total Saved',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${summary.referralRewardsEarned.used}',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      Text(
                        'Rewards Earned by Referring',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(height: 1),
            const SizedBox(height: 16),
            _progressRow(
              theme,
              'First-booking / occasion promo codes',
              summary.publicCodes.used,
              summary.publicCodes.limit,
              verb: 'used',
            ),
            _progressRow(
              theme,
              "Referral codes you've used",
              summary.referralCodesSpent.used,
              summary.referralCodesSpent.limit,
            ),
            _progressRow(
              theme,
              'Referral rewards earned',
              summary.referralRewardsEarned.used,
              summary.referralRewardsEarned.limit,
            ),
            if (summary.pendingReferralRewards > 0) ...[
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(Icons.hourglass_top_rounded,
                      size: 16, color: Colors.amber),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${summary.pendingReferralRewards} referral'
                      '${summary.pendingReferralRewards > 1 ? 's' : ''} pending '
                      '— reward arrives once their trip is completed and paid.',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ActivePromoCard extends StatefulWidget {
  const _ActivePromoCard();

  @override
  State<_ActivePromoCard> createState() => _ActivePromoCardState();
}

class _ActivePromoCardState extends State<_ActivePromoCard>
    with AutomaticKeepAliveClientMixin {
  final _promoCodeService = PromoCodeService();

  bool _loading = true;
  ActivePublicPromo? _promo;
  Timer? _countdownTimer;
  String _countdown = '';

  // Without this, ListView disposes this card's State (and re-fetches from
  // scratch) once it scrolls far enough outside the viewport's cache extent
  // — the exact "reloads every time I scroll" symptom this fixes.
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadPromo();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadPromo() async {
    try {
      final promo = await _promoCodeService.getActivePublicPromo();
      if (!mounted) return;
      setState(() {
        _promo = promo;
        _loading = false;
      });
      _startCountdownIfNeeded();
    } catch (_) {
      // Non-critical section — fail silently, same as the other account cards.
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  void _startCountdownIfNeeded() {
    if (_promo?.expiresAt == null) return;
    _tickCountdown();
    _countdownTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => _tickCountdown());
  }

  void _tickCountdown() {
    final expiresAt = _promo?.expiresAt;
    if (expiresAt == null || !mounted) return;
    setState(() => _countdown = _formatCountdown(expiresAt.difference(DateTime.now())));
  }

  static String _formatCountdown(Duration remaining) {
    if (remaining.isNegative) return 'Expired';
    final days = remaining.inDays;
    final hours = remaining.inHours % 24;
    final minutes = remaining.inMinutes % 60;
    final seconds = remaining.inSeconds % 60;
    if (days > 0) return '${days}d ${hours}h';
    if (hours > 0) return '${hours}h ${minutes}m';
    if (minutes > 0) return '${minutes}m ${seconds}s';
    return '${seconds}s';
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required by AutomaticKeepAliveClientMixin
    if (_loading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: SizedBox(
              height: 24,
              width: 24,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
          ),
        ),
      );
    }

    final promo = _promo;
    if (promo == null) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.local_offer_rounded, color: colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Active Promotion',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'A public promo is a limited-time deal open to every customer, '
              'great for seasonal offers and special occasions.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Text(
                  promo.code,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: colorScheme.primary,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  promo.discountLabel,
                  style: theme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 16,
              runSpacing: 6,
              children: [
                if (_countdown.isNotEmpty)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.timer_outlined,
                          size: 16, color: theme.colorScheme.onSurfaceVariant),
                      const SizedBox(width: 4),
                      Text(
                        'Expires in $_countdown',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                Text(
                  '${promo.remainingUses} use${promo.remainingUses == 1 ? '' : 's'} left for you',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                if ((promo.minFareAmount ?? 0) > 0)
                  Text(
                    'Minimum fare \$${promo.minFareAmount!.toStringAsFixed(2)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReferralCodeCard extends StatefulWidget {
  const _ReferralCodeCard();

  @override
  State<_ReferralCodeCard> createState() => _ReferralCodeCardState();
}

class _ReferralCodeCardState extends State<_ReferralCodeCard>
    with AutomaticKeepAliveClientMixin {
  final _promoCodeService = PromoCodeService();

  bool _loading = true;
  ReferralCodeInfo? _referral;
  bool _copied = false;

  // Without this, ListView disposes this card's State (and re-fetches from
  // scratch) once it scrolls far enough outside the viewport's cache extent
  // — the exact "reloads every time I scroll" symptom this fixes.
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadReferralCode();
  }

  Future<void> _loadReferralCode() async {
    try {
      final referral = await _promoCodeService.getMyReferralCode();
      if (!mounted) return;
      setState(() {
        _referral = referral;
        _loading = false;
      });
    } on ApiException {
      // Non-critical section — fail silently rather than blocking the rest
      // of the account page (mirrors the website's My Account behavior).
      if (!mounted) return;
      setState(() => _loading = false);
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Future<void> _copyLink() async {
    final referral = _referral;
    if (referral == null) return;
    await Clipboard.setData(ClipboardData(text: referral.link));
    if (!mounted) return;
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  Future<void> _shareLink() async {
    final referral = _referral;
    if (referral == null) return;
    await SharePlus.instance.share(
      ShareParams(
        text: referral.shareMessage,
        subject: 'ODA Transportation — Refer a Friend',
        files: await _referralShareImage(),
      ),
    );
  }

  /// Attaches the promo card image alongside the referral text/link so it
  /// shows up as an actual photo in the share sheet (iMessage, WhatsApp,
  /// Instagram DM, ...) — guaranteed, unlike relying on the receiving app to
  /// fetch and unfurl the link's Open Graph preview image, which plain SMS
  /// and some clients never do at all. share_plus needs a real file on disk
  /// to hand to the native share sheet, so the bundled asset is copied to
  /// the OS temp directory once per share (cheap, and self-cleaning).
  Future<List<XFile>> _referralShareImage() async {
    try {
      final asset = await rootBundle.load('assets/images/social_share.jpg');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/oda_referral_share.jpg');
      await file.writeAsBytes(asset.buffer.asUint8List(), flush: true);
      return [XFile(file.path, mimeType: 'image/jpeg')];
    } catch (_) {
      // Missing/unwritable image is never worth blocking the share over —
      // the text/link alone (with its own Open Graph preview) still works.
      return const [];
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required by AutomaticKeepAliveClientMixin
    if (_loading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: SizedBox(
              height: 24,
              width: 24,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
          ),
        ),
      );
    }

    final referral = _referral;
    if (referral == null) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.card_giftcard_rounded, color: colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Refer a Friend',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Your personal code is used to invite unlimited friends. Each gets '
              '${referral.discountValue.toStringAsFixed(0)}% off their first '
              'ride, and you earn a reward every time one completes and pays for it.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: colorScheme.primary.withOpacity(0.08),
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: Text(
                referral.code,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: colorScheme.primary,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    referral.link,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  onPressed: _copyLink,
                  tooltip: 'Copy link',
                  icon: Icon(
                    _copied ? Icons.check_rounded : Icons.copy_rounded,
                    color: _copied ? colorScheme.primary : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _shareLink,
                icon: const Icon(Icons.share_rounded, size: 18),
                label: const Text('Share'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.icon,
    required this.iconColor,
    required this.children,
  });

  final String title;
  final IconData icon;
  final Color iconColor;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(AppSpacing.sm),
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Icon(icon, color: iconColor, size: 24),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.onTap,
    this.badge,
    this.iconColor,
  });

  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final int? badge;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final effectiveIconColor = iconColor ?? theme.colorScheme.primary;
    return ListTile(
      leading: Icon(icon, color: effectiveIconColor),
      title: Text(
        title,
        style: iconColor != null ? TextStyle(color: iconColor) : null,
      ),
      trailing: badge != null
          ? Badge(
              label: Text('$badge'),
              child: const Icon(Icons.chevron_right),
            )
          : const Icon(Icons.chevron_right),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
    );
  }
}
